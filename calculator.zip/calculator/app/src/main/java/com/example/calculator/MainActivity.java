package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    boolean functionFlag=false;//בשביל לדעת אם לשרשר למחרוזת או למחוק ולעשות חדשה
    boolean ErrorFlag=false;

    TextView res;
    int num1=0;

    int num2;
    int sum;
    int counterNum=0;
    String strBtn;
    String tempLastMethod;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

            res=findViewById(R.id.text_view);




    }


    public void numberClickFun(View view) {

        Button button=(Button) view;
        if(functionFlag){
             String str=button.getText().toString();
            res.setText(str);
            functionFlag=false;
        }
        else{
            String str=button.getText().toString();
            res.append(str);
        }


    }

    public void delete_fun(View view) {
        num1=0;
        num2=0;
        counterNum=0;
        functionFlag=false;
        res.setText("");
    }


    public void equal_fun(View view) {

        String str =res.getText().toString();
        num2=Integer.parseInt(str);
        calc(num1,num2,strBtn);
        str=String.valueOf(sum);

        if(ErrorFlag){

            res.setText("Error--> push AC");
            ErrorFlag=false;
        }
        else{
            res.setText(str);
        }
        counterNum=0;

    }
    public void equal_fun(String s) {

        String str =res.getText().toString();
        num2=Integer.parseInt(str);
        calc(num1,num2,s);
        str=String.valueOf(sum);
        if(ErrorFlag){
            res.setText("Error--> push AC");
            ErrorFlag=false;
        }
       else{
            res.setText(str);
        }

        counterNum=0;

    }


    public void method_fun(View view) {
        Button button=(Button) view;
        strBtn=button.getText().toString();

        if (counterNum>0){
            String str =res.getText().toString();
            if(Integer.parseInt(str)<=Integer.MAX_VALUE) {
                num2 = Integer.parseInt(str);
                equal_fun(tempLastMethod);
                num1 = sum;
            }
            else{ErrorFlag=true;
                equal_fun(strBtn);

            }
        }
    else{
            String str = res.getText().toString();

            if(Integer.parseInt(str)<=Integer.MAX_VALUE)
            {

                num1 = Integer.parseInt(str);
            }
            else
            {
                    ErrorFlag=true;
                    equal_fun(strBtn);
            }
        }


        functionFlag=true;
        tempLastMethod=strBtn;
        counterNum++;


    }

    public void calc(int number1,int number2,String s){
        switch (s){
            case "+":
            {

                sum= number1+number2;
                break;
            }
            case "-":{
                sum= number1-number2;
                break;
            }
            case "*": {
                sum= number1 * number2;
                break;
            }
            case "/": {
                if (number2 == 0) {
                    ErrorFlag=true;
                    num1 = 0;
                    num2 = 0;
                    counterNum = 0;
                    functionFlag = false;
                    break;
                } else
                    sum= number1 / number2;
            }

        }

    }







}